import { NeuroCheckout } from '@/components/neuro-checkout'

export default function Page() {
  return (
    <main className="min-h-screen bg-background text-foreground">
      <NeuroCheckout />
    </main>
  )
}
