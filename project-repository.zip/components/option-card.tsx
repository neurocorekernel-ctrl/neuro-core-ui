import type { LucideIcon } from 'lucide-react'
import { cn } from '@/lib/utils'

interface OptionCardProps {
  icon: LucideIcon
  label: string
  tag: string
  index: number
  pruned: boolean
  children: React.ReactNode
}

export function OptionCard({
  icon: Icon,
  label,
  tag,
  index,
  pruned,
  children,
}: OptionCardProps) {
  return (
    <div
      aria-hidden={pruned}
      className={cn(
        'group relative rounded-xl border border-border bg-card/60 p-5 backdrop-blur-sm transition-all duration-700 ease-out',
        pruned
          ? 'pointer-events-none scale-[0.98] opacity-15 blur-[1px]'
          : 'opacity-100 hover:border-primary/40',
      )}
      style={{ transitionDelay: pruned ? `${index * 40}ms` : '0ms' }}
    >
      <div className="mb-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg border border-border bg-secondary text-primary">
            <Icon className="h-4 w-4" aria-hidden="true" />
          </div>
          <span className="text-sm font-medium text-foreground">{label}</span>
        </div>
        <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
          {tag}
        </span>
      </div>
      {children}
    </div>
  )
}
