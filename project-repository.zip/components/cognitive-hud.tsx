import { Activity, BrainCircuit } from 'lucide-react'
import { cn } from '@/lib/utils'

interface CognitiveHudProps {
  load: number
  pruned: boolean
}

export function CognitiveHud({ load, pruned }: CognitiveHudProps) {
  const rounded = Math.round(load)
  const status = pruned
    ? 'PRUNING ACTIVE'
    : load > 66
      ? 'HIGH LOAD'
      : load > 33
        ? 'ELEVATED'
        : 'NOMINAL'

  return (
    <div className="flex flex-col gap-3 rounded-xl border border-border bg-card/60 px-4 py-3 backdrop-blur-sm sm:flex-row sm:items-center sm:gap-5">
      <div className="flex items-center gap-2.5">
        <span className="relative flex h-2.5 w-2.5">
          <span
            className={cn(
              'absolute inline-flex h-full w-full rounded-full opacity-75',
              pruned ? 'bg-destructive animate-ping' : 'bg-primary animate-ping',
            )}
          />
          <span
            className={cn(
              'relative inline-flex h-2.5 w-2.5 rounded-full',
              pruned ? 'bg-destructive' : 'bg-primary',
            )}
          />
        </span>
        <BrainCircuit className="h-4 w-4 text-primary" aria-hidden="true" />
        <span className="font-mono text-xs font-medium uppercase tracking-[0.2em] text-foreground">
          NEURO-CORE
        </span>
        <span className="hidden font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground sm:inline">
          Monitoring Cognitive Load
        </span>
      </div>

      <div className="flex flex-1 items-center gap-3">
        <div className="relative h-1.5 flex-1 overflow-hidden rounded-full bg-secondary">
          <div
            className={cn(
              'absolute inset-y-0 left-0 rounded-full transition-all duration-200 ease-out',
              pruned || load > 66 ? 'bg-destructive' : 'bg-primary',
            )}
            style={{ width: `${load}%` }}
          />
        </div>
        <div className="flex w-28 items-center justify-end gap-1.5">
          <Activity
            className={cn(
              'h-3.5 w-3.5',
              pruned || load > 66 ? 'text-destructive' : 'text-primary',
            )}
            aria-hidden="true"
          />
          <span
            className={cn(
              'font-mono text-xs tabular-nums',
              pruned || load > 66 ? 'text-destructive' : 'text-muted-foreground',
            )}
          >
            {rounded}% · {status}
          </span>
        </div>
      </div>
    </div>
  )
}
