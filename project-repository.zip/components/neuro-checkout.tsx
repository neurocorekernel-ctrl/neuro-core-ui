'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import {
  BadgePercent,
  CreditCard,
  Gift,
  MapPin,
  Receipt,
  ShieldCheck,
  Sparkles,
  Truck,
  Zap,
  RotateCcw,
  Check,
  ChevronRight,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { CognitiveHud } from '@/components/cognitive-hud'
import { OptionCard } from '@/components/option-card'

const IDLE_THRESHOLD_MS = 450
const LOAD_LIMIT = 100
const PRUNE_AT = 92

export function NeuroCheckout() {
  const [load, setLoad] = useState(0)
  const [pruned, setPruned] = useState(false)
  const [ordered, setOrdered] = useState(false)
  const lastActivity = useRef<number>(Date.now())
  const prunedRef = useRef(false)

  useEffect(() => {
    prunedRef.current = pruned
  }, [pruned])

  const registerActivity = useCallback(() => {
    lastActivity.current = Date.now()
  }, [])

  // Simulated cognitive-load engine: load climbs while the user hesitates
  // (idle) across a dense form, and eases back down during active input.
  useEffect(() => {
    const interval = setInterval(() => {
      if (prunedRef.current || ordered) return
      const idleFor = Date.now() - lastActivity.current
      setLoad((prev) => {
        const next =
          idleFor > IDLE_THRESHOLD_MS
            ? prev + 1.4
            : Math.max(0, prev - 3)
        const clamped = Math.min(LOAD_LIMIT, next)
        if (clamped >= PRUNE_AT) {
          setPruned(true)
          return LOAD_LIMIT
        }
        return clamped
      })
    }, 120)
    return () => clearInterval(interval)
  }, [ordered])

  const triggerOverload = () => {
    setPruned(true)
    setLoad(LOAD_LIMIT)
  }

  const reset = () => {
    setPruned(false)
    setOrdered(false)
    setLoad(0)
    lastActivity.current = Date.now()
  }

  return (
    <div
      onMouseMove={registerActivity}
      onKeyDown={registerActivity}
      onPointerDown={registerActivity}
      className="relative min-h-screen w-full overflow-hidden"
    >
      {/* Ambient grid backdrop */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 opacity-40"
        style={{
          backgroundImage:
            'linear-gradient(to right, color-mix(in oklch, var(--border) 60%, transparent) 1px, transparent 1px), linear-gradient(to bottom, color-mix(in oklch, var(--border) 60%, transparent) 1px, transparent 1px)',
          backgroundSize: '52px 52px',
          maskImage:
            'radial-gradient(ellipse 80% 60% at 50% 0%, black 40%, transparent 100%)',
        }}
      />

      <div className="relative mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:py-12">
        {/* Header */}
        <header className="mb-8 flex flex-col gap-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary text-primary-foreground">
                <Sparkles className="h-4 w-4" aria-hidden="true" />
              </div>
              <span className="font-mono text-sm font-semibold uppercase tracking-[0.25em] text-foreground">
                Aether
              </span>
            </div>
            <span className="font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
              Secure Checkout · TLS 1.3
            </span>
          </div>
          <CognitiveHud load={load} pruned={pruned} />
        </header>

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-[1fr_380px]">
          {/* ---- Options panel ---- */}
          <section className="relative">
            {/* Darkening overlay when pruned */}
            <div
              aria-hidden="true"
              className={cn(
                'pointer-events-none absolute inset-0 z-10 rounded-2xl bg-background transition-opacity duration-700',
                pruned ? 'opacity-55' : 'opacity-0',
              )}
            />

            <div className="mb-5 flex items-center justify-between">
              <h1 className="text-lg font-semibold tracking-tight text-foreground">
                {pruned ? 'Optimized Checkout' : 'Complete your order'}
              </h1>
              <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
                {pruned ? '1 essential step' : '8 options'}
              </span>
            </div>

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <OptionCard
                icon={MapPin}
                label="Shipping Address"
                tag="01"
                index={0}
                pruned={pruned}
              >
                <div className="space-y-2.5">
                  <FakeInput placeholder="221B Baker Street" />
                  <div className="grid grid-cols-2 gap-2.5">
                    <FakeInput placeholder="London" />
                    <FakeInput placeholder="NW1 6XE" />
                  </div>
                </div>
              </OptionCard>

              <OptionCard
                icon={CreditCard}
                label="Payment Method"
                tag="02"
                index={1}
                pruned={pruned}
              >
                <div className="space-y-2.5">
                  <FakeInput placeholder="•••• •••• •••• 4242" mono />
                  <div className="grid grid-cols-2 gap-2.5">
                    <FakeInput placeholder="12 / 28" mono />
                    <FakeInput placeholder="CVC" mono />
                  </div>
                </div>
              </OptionCard>

              <OptionCard
                icon={BadgePercent}
                label="Discount Code"
                tag="03"
                index={2}
                pruned={pruned}
              >
                <div className="flex gap-2.5">
                  <FakeInput placeholder="NEURO-10" mono />
                  <button className="shrink-0 rounded-lg border border-border bg-secondary px-3 text-xs font-medium text-foreground transition-colors hover:border-primary/40">
                    Apply
                  </button>
                </div>
              </OptionCard>

              <OptionCard
                icon={Truck}
                label="Shipping Speed"
                tag="04"
                index={3}
                pruned={pruned}
              >
                <div className="grid grid-cols-3 gap-2">
                  <Pill label="Standard" />
                  <Pill label="Express" active />
                  <Pill label="Same-day" />
                </div>
              </OptionCard>

              <OptionCard
                icon={ShieldCheck}
                label="Shipment Insurance"
                tag="05"
                index={4}
                pruned={pruned}
              >
                <ToggleRow label="Protect against loss & damage" price="+$12" />
              </OptionCard>

              <OptionCard
                icon={Gift}
                label="Gift Wrapping"
                tag="06"
                index={5}
                pruned={pruned}
              >
                <ToggleRow label="Premium matte box + note" price="+$8" />
              </OptionCard>

              <OptionCard
                icon={Receipt}
                label="Billing Address"
                tag="07"
                index={6}
                pruned={pruned}
              >
                <ToggleRow label="Same as shipping address" price="" active />
              </OptionCard>

              <OptionCard
                icon={Sparkles}
                label="Loyalty Rewards"
                tag="08"
                index={7}
                pruned={pruned}
              >
                <ToggleRow label="Redeem 2,400 points" price="−$24" />
              </OptionCard>
            </div>
          </section>

          {/* ---- Order summary / CTA ---- */}
          <aside className="lg:sticky lg:top-8 lg:self-start">
            <div className="overflow-hidden rounded-2xl border border-border bg-card/70 backdrop-blur-sm">
              <div className="relative aspect-[4/3] w-full bg-secondary/40">
                <img
                  src="/product.png"
                  alt="Aether One reference-grade titanium headphones"
                  className="h-full w-full object-cover"
                />
                <div className="absolute left-3 top-3 rounded-full border border-border bg-background/70 px-2.5 py-1 font-mono text-[10px] uppercase tracking-widest text-foreground backdrop-blur-sm">
                  Limited · 1 of 500
                </div>
              </div>

              <div className="space-y-4 p-5">
                <div>
                  <h2 className="text-base font-semibold tracking-tight text-foreground">
                    Aether One
                  </h2>
                  <p className="text-sm text-muted-foreground">
                    Reference-grade titanium headphones
                  </p>
                </div>

                <div className="space-y-2 border-y border-border py-4 font-mono text-xs">
                  <SummaryRow label="Subtotal" value="$1,299.00" />
                  <SummaryRow label="Express shipping" value="$24.00" />
                  <SummaryRow label="Estimated tax" value="$103.92" />
                  <div className="flex items-center justify-between pt-2 text-sm">
                    <span className="font-medium text-foreground">Total</span>
                    <span className="font-semibold text-foreground">
                      $1,426.92
                    </span>
                  </div>
                </div>

                {/* Primary action — scales & glows when pruned */}
                <button
                  onClick={() => setOrdered(true)}
                  className={cn(
                    'group relative flex w-full items-center justify-center gap-2 rounded-xl bg-primary font-semibold text-primary-foreground transition-all duration-500 ease-out',
                    pruned
                      ? 'z-20 scale-[1.04] px-6 py-5 text-base shadow-[0_0_0_1px_var(--primary),0_0_45px_-4px_var(--primary)]'
                      : 'px-5 py-3.5 text-sm hover:brightness-110',
                    ordered && 'bg-primary',
                  )}
                >
                  {ordered ? (
                    <>
                      <Check className="h-5 w-5" aria-hidden="true" />
                      Order Confirmed
                    </>
                  ) : pruned ? (
                    <>
                      <Zap className="h-5 w-5" aria-hidden="true" />
                      Complete Order with 1-Click
                    </>
                  ) : (
                    <>
                      Review &amp; Place Order
                      <ChevronRight
                        className="h-4 w-4 transition-transform group-hover:translate-x-0.5"
                        aria-hidden="true"
                      />
                    </>
                  )}
                </button>

                {pruned && !ordered && (
                  <p className="text-center font-mono text-[10px] uppercase tracking-widest text-primary">
                    Interface pruned · distractions suppressed
                  </p>
                )}

                <p className="flex items-center justify-center gap-1.5 text-center text-xs text-muted-foreground">
                  <ShieldCheck className="h-3.5 w-3.5" aria-hidden="true" />
                  30-day returns · encrypted payment
                </p>
              </div>
            </div>

            {/* Controls */}
            <div className="mt-4 flex flex-col gap-2.5">
              <button
                onClick={triggerOverload}
                disabled={pruned}
                className={cn(
                  'flex w-full items-center justify-center gap-2 rounded-xl border px-4 py-3 text-sm font-medium transition-all',
                  pruned
                    ? 'cursor-not-allowed border-border text-muted-foreground opacity-50'
                    : 'border-destructive/40 bg-destructive/10 text-destructive hover:bg-destructive/20',
                )}
              >
                <Zap className="h-4 w-4" aria-hidden="true" />
                Simulate Cognitive Overload
              </button>

              {pruned && (
                <button
                  onClick={reset}
                  className="flex w-full items-center justify-center gap-2 rounded-xl border border-border bg-secondary px-4 py-3 text-sm font-medium text-foreground transition-colors hover:border-primary/40"
                >
                  <RotateCcw className="h-4 w-4" aria-hidden="true" />
                  Restore All Options
                </button>
              )}

              <p className="px-1 text-center text-[11px] leading-relaxed text-muted-foreground">
                {pruned
                  ? 'NEURO-CORE detected decision fatigue and collapsed the flow to a single high-confidence action.'
                  : 'Hesitate on the form or trigger overload to watch NEURO-CORE dynamically prune the interface.'}
              </p>
            </div>
          </aside>
        </div>
      </div>
    </div>
  )
}

function FakeInput({
  placeholder,
  mono,
}: {
  placeholder: string
  mono?: boolean
}) {
  return (
    <input
      type="text"
      placeholder={placeholder}
      className={cn(
        'w-full rounded-lg border border-input bg-background/50 px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary/60 focus:outline-none focus:ring-1 focus:ring-primary/40',
        mono && 'font-mono',
      )}
    />
  )
}

function SummaryRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between text-muted-foreground">
      <span>{label}</span>
      <span className="tabular-nums text-foreground">{value}</span>
    </div>
  )
}

function Pill({ label, active }: { label: string; active?: boolean }) {
  return (
    <button
      className={cn(
        'rounded-lg border px-2 py-2 text-center text-xs font-medium transition-colors',
        active
          ? 'border-primary/60 bg-primary/15 text-primary'
          : 'border-border bg-background/50 text-muted-foreground hover:border-primary/40',
      )}
    >
      {label}
    </button>
  )
}

function ToggleRow({
  label,
  price,
  active,
}: {
  label: string
  price: string
  active?: boolean
}) {
  return (
    <div className="flex items-center justify-between gap-3">
      <span className="text-xs text-muted-foreground">{label}</span>
      <div className="flex items-center gap-2.5">
        {price && (
          <span className="font-mono text-xs text-foreground">{price}</span>
        )}
        <span
          className={cn(
            'flex h-5 w-9 items-center rounded-full border p-0.5 transition-colors',
            active
              ? 'justify-end border-primary/60 bg-primary/30'
              : 'justify-start border-border bg-secondary',
          )}
        >
          <span
            className={cn(
              'h-3.5 w-3.5 rounded-full transition-colors',
              active ? 'bg-primary' : 'bg-muted-foreground',
            )}
          />
        </span>
      </div>
    </div>
  )
}
